# There should be a way of loading automatically

import cucats.exercise1 as e1
import cucats.exercise2 as e2

version = 1.2
ex1 = e1.Exercise1()
ex2 = e2.Exercise2()