# There should be a way of loading automatically

from cucats import exercise1,exercise2,demo,fizzbuzz

version = 2.0
demo1 = demo.Demo1()
demo2 = demo.Demo2()
ex1 = exercise1.Exercise1()
ex2 = exercise2.Exercise2()
fizzbuzz = fizzbuzz.Exercise()

exercises = ['ex1','ex2','demo1','demo2','fizzbuzz']