# -*- coding: utf-8 -*-
"""
Created on Fri Feb 13 19:14:49 2015

@author: Daniel
"""

class CUCATSWrapper:
    