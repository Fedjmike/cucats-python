# -*- coding: utf-8 -*-
"""
Created on Thu Feb 12 23:13:00 2015

@author: Daniel
"""
from cucats.wrapper import Wrapper
from random import random as rand
CORRECT = "CORRECT!"

wrap = Wrapper()
wrap.foo

def printCorrect():
    print("Correct! Well done!")

def printNoInput():
    print("It looks like you have not implemented your function")

def printWrong(given_answer = None,correct_answer = None):
    if (correct_answer):
        print("Wrong!\n Expected output:", correct_answer, "\nYour output:", given_answer)
    elif (given_answer):
        print("to be implemented")
    else:
        print("Incorrect answer. Please try again.")

# Assume solveMe exists
def ex1(solveMe=None):     
    # Check whether function exists
    if (solveMe):
        test_input = [];
        test_output = [];
        for (f_in,out) in zip(test_input, test_output):
            if (solveMe(f_in)!=out):
                print("Wrong!\n Expected output:", out, "\nYour output:", solveMe(f_in))
                return
        else:
            print("Correct!")
    else:
        print("It looks like you have not implemented your function")


def calculator(answer=None):
    if (not answer):
        printNoInput()
        return
    ans = 2**1000;
    if (answer == ans):
        print (CORRECT)
    else:
        printWrong(answer)
        
def squaring(f):
    if (not f):
        printNoInput()
        return
    test = [int(rand()*1000) for i in range(100)]
    answer = [x*x for x in test]
    user_answer = [f(x) for x in test]
    if (answer == user_answer):
        printCorrect()
    else:
        printWrong(user_answer, answer)