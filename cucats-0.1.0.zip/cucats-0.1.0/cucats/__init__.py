#import wrapper
def main():
    """Entry point for the application script"""
    print("Call your main application code here 1.0")
    
version = 1.0