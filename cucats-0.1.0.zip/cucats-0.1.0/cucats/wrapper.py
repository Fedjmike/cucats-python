# -*- coding: utf-8 -*-
"""
Created on Sat Feb 14 16:35:26 2015

@author: Daniel
"""

class Wrapper:
    def __init__(self):
        print("hi")
    def foo():
        return 2
